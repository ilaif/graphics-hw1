package graphics.hw1;

public enum ForwardEnergyDirection {
    LEFT,
    RIGHT,
    UP
}
