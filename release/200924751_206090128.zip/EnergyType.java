package graphics.hw1;

public enum EnergyType {
    REGULAR,
    ENTROPY,
    FORWARD_ENERGY
}
